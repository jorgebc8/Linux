Ejercicios cron, squid e iptables.
Realizar los siguientes ejercicios cron(comprobando su ejecución)
Ejecutará el script test1.sh a las 10:15 a.m. todos los días
Usuario root ejecutará una actualización todos los domingos a las 10:00 a.m
El día 20 de noviembre a las 7:30 el usuario correrá el script
El usertest ejecutará el script el día 10 de febrero a las 00:30 a.m. y que sea domingo.
Se ejecutará a las 5:30 de la tarde todos los días de lunes a viernes.
Ejecutar un script de lunes a viernes a las 2:30 horas:
Ejecutar un script de lunes a viernes cada 10 minutos desde las 2:00 horas durante una hora:
Se comprobarán todos los cron. Todos los cron ejecutarán un script que guarde en un fichero la hora y la fecha

Ejercicios cron (2).
Cada hora en punto ejecutamos la sincronización horaria y mandamos la salida a /dev/null/
Programar un trabajo (A) para ejecutarse en el minuto 30 de cada hora de cada día.
Programar un trabajo (B) para ejecutarse cada día a las 20:30h.
Programar un trabajo (C) para ejecutarse de lunes a viernes a las 20:30h.
Programar un trabajo (D) para ejecutarse los martes y los jueves a las 20:30h.
Programar un trabajo (E) para ejecutarse los días 10 y 20 de todos los meses a las 20:30h.
Programar un trabajo (F) para ejecutarse cada 15 minutos.
Programar un trabajo (G) para ejecutarse cada día a las 00:00h.
Programar un trabajo (H) para ejecutarse cada primer día de mes a las 00:00h.
El trabajo que se debe ejecutar es:
Añadir al fichero /etc/trabajos (no existe hay que crearlo) el código del trabajo y la hora de ejecución.
Squid
Instalar y configurar un proxy, comprobar su funcionamiento.

bloquear las siguientes páginas:

www.marca.es
www.iesayala.com
No permitir accesos desde una red diferente a la de la máquina virtual.

proxy transparente y router (esta parte es opcional)
Crear una router con un proxy transparente.
